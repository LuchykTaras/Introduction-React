import { city } from "../data";

export default function CityFunctional() {
  return (
    <section className="content-section">
      <div className="intro">
        <span className="eyebrow">Завдання 1 · Функціональні компоненти</span>
        <h2>{city.name}</h2>
        <p className="lead">{city.description}</p>
      </div>
      <div className="facts">
        <div className="fact"><span>Країна</span><strong>{city.country}</strong></div>
        <div className="fact"><span>Рік заснування</span><strong>{city.founded}</strong></div>
      </div>
      <h3 className="section-heading">Цікаві місця та краєвиди</h3>
      <div className="photo-grid">
        {city.photos.map((photo) => (
          <article className="photo-card" key={photo.title}>
            <img src={photo.image} alt={photo.title} />
            <div className="card-copy">
              <h4>{photo.title}</h4>
              <p>{photo.description}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
