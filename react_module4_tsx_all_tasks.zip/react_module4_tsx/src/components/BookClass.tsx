import { Component } from "react";
import { book } from "../data";

export default class BookClass extends Component {
  render() {
    return (
      <section className="content-section">
        <div className="intro">
          <span className="eyebrow">Завдання 4 · Класові компоненти</span>
          <h2>{book.title}</h2>
          <p className="lead">{book.description}</p>
        </div>
        <div className="facts book-facts">
          <div className="fact"><span>Автор</span><strong>{book.author}</strong></div>
          <div className="fact"><span>Жанр</span><strong>{book.genre}</strong></div>
          <div className="fact"><span>Кількість сторінок</span><strong>{book.pages}</strong></div>
        </div>
        <h3 className="section-heading">Рецензії читачів</h3>
        <div className="review-list">
          {book.reviews.map((review) => (
            <article className="review" key={review.author}>
              <div className="review-avatar">{review.author[0]}</div>
              <div><h4>{review.author}</h4><p>{review.text}</p></div>
            </article>
          ))}
        </div>
      </section>
    );
  }
}
