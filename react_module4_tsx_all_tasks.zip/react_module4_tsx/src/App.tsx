import { useState } from "react";
import CityFunctional from "./components/CityFunctional";
import CityClass from "./components/CityClass";
import BookFunctional from "./components/BookFunctional";
import BookClass from "./components/BookClass";

const tasks = [
  { id: "city-function", label: "Місто", detail: "Функціональний", group: "Місто" },
  { id: "city-class", label: "Місто", detail: "Класовий", group: "Місто" },
  { id: "book-function", label: "Книга", detail: "Функціональний", group: "Книга" },
  { id: "book-class", label: "Книга", detail: "Класовий", group: "Книга" }
] as const;

type TaskId = typeof tasks[number]["id"];

export default function App() {
  const [activeTask, setActiveTask] = useState<TaskId>("city-function");

  const renderTask = () => {
    switch (activeTask) {
      case "city-function": return <CityFunctional />;
      case "city-class": return <CityClass />;
      case "book-function": return <BookFunctional />;
      case "book-class": return <BookClass />;
    }
  };

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand-mark">R</div>
        <div>
          <p className="course-label">Курс · Використання фреймворків Angular, React</p>
          <h1>Модуль 4 <span>/</span> Вступ до React</h1>
        </div>
        <div className="tsx-pill">React + TypeScript · TSX</div>
      </header>

      <section className="hero">
        <div>
          <span className="eyebrow">Навчальний проєкт</span>
          <h2>Чотири завдання.<br /><em>Один застосунок.</em></h2>
          <p>Порівняй функціональні та класові компоненти React на прикладах міста й улюбленої книги.</p>
        </div>
        <div className="hero-orbit" aria-hidden="true"><span>JSX</span><b>TSX</b><i>R</i></div>
      </section>

      <nav className="task-nav" aria-label="Навігація завдань">
        {tasks.map((task, index) => {
          const id = task.id as TaskId;
          return (
            <button
              key={task.id}
              className={`task-button ${activeTask === id ? "active" : ""}`}
              onClick={() => setActiveTask(id)}
              aria-pressed={activeTask === id}
            >
              <span className="task-number">0{index + 1}</span>
              <span className="task-button-copy">
                <strong>{task.group}</strong>
                <small>{task.detail}</small>
              </span>
            </button>
          );
        })}
      </nav>

      <div className="panel">{renderTask()}</div>

      <footer>
        <span>Навчальний проєкт · Модуль 4</span>
        <span>Створено на React з TypeScript (TSX)</span>
      </footer>
    </main>
  );
}
