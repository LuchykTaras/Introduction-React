export type CityPhoto = {
  title: string;
  description: string;
  image: string;
};

export const city = {
  name: "Вінниця",
  country: "Україна",
  founded: "1363 рік",
  description:
    "Вінниця — місто на берегах Південного Бугу, відоме затишними вулицями, набережною та світломузичним фонтаном Roshen.",
  photos: [
    {
      title: "Вежа Артинова",
      description: "Одна з найвідоміших історичних споруд міста.",
      image:
        "https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1000&q=85"
    },
    {
      title: "Набережна Південного Бугу",
      description: "Місце для прогулянок і відпочинку біля води.",
      image:
        "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1000&q=85"
    },
    {
      title: "Міські краєвиди",
      description: "Архітектура та атмосфера сучасного міста.",
      image:
        "https://images.unsplash.com/photo-1511818966892-d7d671e672a2?auto=format&fit=crop&w=1000&q=85"
    }
  ] satisfies CityPhoto[]
};

export const book = {
  title: "Гобіт, або Туди і звідти",
  author: "Джон Рональд Руел Толкін",
  genre: "Фентезі, пригодницька література",
  pages: 310,
  description:
    "Історія про Більбо Торбина, який вирушає у небезпечну мандрівку разом із гномами, щоб повернути скарби, захоплені драконом Смоґом.",
  reviews: [
    {
      author: "Марія",
      text: "Захоплива пригода з яскравим світом, гумором і незабутніми персонажами."
    },
    {
      author: "Олександр",
      text: "Книга нагадує, що навіть звичайна людина здатна на великі вчинки."
    },
    {
      author: "Ірина",
      text: "Читається легко, а атмосфера подорожі тримає увагу до останньої сторінки."
    }
  ]
};
